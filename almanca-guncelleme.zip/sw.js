// Çevrimdışı çalışma: uygulama dosyalarını telefona kaydeder.
const CACHE = "almanca-v2";
const FILES = ["./", "index.html", "manifest.webmanifest", "icon-192.png", "icon-512.png", "icon-maskable-512.png", "apple-touch-icon.png"];

self.addEventListener("install", e => {
  e.waitUntil((async () => {
    const c = await caches.open(CACHE);
    // Her dosyayı ayrı kaydet: biri başarısız olsa da diğerleri kalsın.
    await Promise.all(FILES.map(async f => {
      try { const res = await fetch(new Request(f, {cache: "reload"})); if (res.ok) await c.put(new URL(f, self.registration.scope).href, res); } catch (err) {}
    }));
    await self.skipWaiting();
  })());
});

self.addEventListener("activate", e => {
  e.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter(k => k.startsWith("almanca-") && k !== CACHE).map(k => caches.delete(k)));
    await self.clients.claim();
  })());
});

self.addEventListener("fetch", e => {
  const req = e.request;
  if (req.method !== "GET") return;
  const url = new URL(req.url);
  const isFont = url.hostname === "fonts.googleapis.com" || url.hostname === "fonts.gstatic.com";
  if (url.origin !== location.origin && !isFont) return;

  // Sayfanın kendisi: önce kayıtlı kopya, yoksa internet.
  if (req.mode === "navigate") {
    e.respondWith((async () => {
      const cached = await caches.match(new URL("./", self.registration.scope).href) || await caches.match(new URL("index.html", self.registration.scope).href);
      const net = fetch(req).then(async res => {
        if (res.ok && !res.redirected) { const c = await caches.open(CACHE); await c.put(new URL("./", self.registration.scope).href, res.clone()); }
        return res;
      }).catch(() => null);
      if (cached) { e.waitUntil(net); return cached; }
      return (await net) || new Response("<h1>İnternet yok</h1><p>Uygulamayı bir kez internete bağlıyken aç.</p>", {headers: {"Content-Type": "text/html; charset=utf-8"}});
    })());
    return;
  }

  // Diğer dosyalar ve yazı tipleri
  e.respondWith((async () => {
    const cached = await caches.match(req, {ignoreSearch: true});
    const net = fetch(req).then(async res => {
      if (res && (res.ok || res.type === "opaque")) { const c = await caches.open(CACHE); await c.put(req, res.clone()); }
      return res;
    }).catch(() => null);
    if (cached) { e.waitUntil(net); return cached; }
    return (await net) || Response.error();
  })());
});
